#ifndef basis_H
#define basis_H

#include <iostream>
#include <iomanip>
#include <vector>
#include <Eigen/Dense>

#include "HOstate.h"
#include "coupling.h"

using namespace std;
using namespace Eigen;

class basis {
public:
  // Constructs the physical states in the restricted HO basis with center of mass energy E<=nmax+3
  // and total angular momentum J
  basis(int set_nmax,int set_J); 
  ~basis();
  
  // Changes the basis of available states
  // SHOULD IMPROVE EFFICIENCY
  // 1. If basis made larger, need only calculate new shells
  // 2. If basis made smaller, can just forget extra shells
  void set(int set_nmax,int set_J);

  // These functions return values of private class variables
  int nmax() {return nmax_;};
  int J() {return J_;};
  unsigned int basisDim() {return basisDim_;};
  unsigned int statesDim() {return statesDim_;};

  HOstate getBasisState(unsigned int i); // Gets states from the HO basis
  VectorXd getState(unsigned int i) {return states_.col(i);}; // Gets the representations of the three body states in the HO basis

  void printBasis();
  void printSymmetrizer();
  void printStates();

  void sortStates(); // Sorts the basis states in order of increasing energy

protected:
  int nmax_; // POOR NOMENCLATURE. Highest energy allowed is E=nmax_+3
  int J_; // States will all have total angular momentum J_

  void Init(); 

  unsigned int basisDim_; // Number of HO basis kets
  unsigned int statesDim_; // Number of physical states with correct permutation symmetry

  Matrix<HOstate, Dynamic, 1> fullBasis; // The array of basis kets is handled using the Eigen routines, not sure if this is best
  MatrixXd symmetrizer_; // The matrix \Pi
  MatrixXd states_; // Contains the representation in the HO basis of states with proper permutation symmetry

  void popBasis(); // Finds all basis states with l even and E<=nmax-3
  void popSymmetrizer(); // Creates the matrix 1/3*(1+2*\Pi)
  void calcSymBasis(); // Finds the (anti)symmetric three particle basis states
  

};

#endif
