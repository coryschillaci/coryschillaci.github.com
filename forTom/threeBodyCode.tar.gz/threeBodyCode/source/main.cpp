#include <iostream>
#include <iomanip>
#include <math.h>
#include "gamma.h"
#include "coupling.h"
#include "basis.h"
#include "energies.h"

#define PI 3.14159265358979
#define ROOT_PI 1.77245385090552
#define DOUBLE_INFINITY 1.7e308

using namespace std;

string makeFilename(int Lambda);

int main () {

  int LambdaMin=4;
  int LambdaMax=44;
  int LambdaStep=4;

  basis workingBasis(LambdaMin,0);

  cout<<"Beginning with Lambda="<<LambdaMin<<"\n";
  cout<<"The number of basis states is "<<workingBasis.basisDim()<<".\n";
  cout<<"The number of permutation symmetric states is "<<workingBasis.statesDim()<<".\n";

  workingBasis.sortStates();
  
  // energies( basis set_basis, double set_aInvMin, double set_aInvMax, double set_aInvStep, double set_eMin, double set_eMax, double set_eStep )
  energies pairs (workingBasis, -3, 3.5, .075, -1,7, sqrt(2)/100);
  
  
  //cout<<"Initial pairs calculated.\n";

  // pairs.sortPairsByA();

  cout<<"Ready to write data.\n";

  pairs.writePairs(makeFilename(LambdaMin));

  cout<<"The calculation for Lambda="<<LambdaMin<<" is now completed. All data has been saved.\n\n";

  for(int Lambda=LambdaMin+LambdaStep;Lambda<=LambdaMax;Lambda++) {

    cout<<"Now calculating for Lambda="<<Lambda<<"\n";

    workingBasis.set(Lambda,0);

    cout<<"The number of basis states is "<<workingBasis.basisDim()<<".\n";
    cout<<"The number of permutation symmetric states is "<<workingBasis.statesDim()<<".\n";

    pairs.setBasis(workingBasis);

    //    pairs.sortPairsByA();

    pairs.writePairs(makeFilename(Lambda));

    cout<<"The calculation for Lambda="<<Lambda<<" is now completed. All data has been saved.\n\n";
  }

}


string makeFilename(int Lambda) {

  string filename="../data/PairsByAForLambda";
  
  stringstream temp;
  temp<<Lambda;
  filename+=temp.str();
  filename+=".csv";

  return filename;

}
