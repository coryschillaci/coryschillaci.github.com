#include "energies.h"

// Constructor
energies::energies(basis set_basis) : basis_(set_basis) {
  Init();
}

energies::energies( basis set_basis, double set_aInvMin, double set_aInvMax, double set_aInvStep, double set_eMin, double set_eMax, double set_eStep ) : aInvMin_(set_aInvMin),aInvMax_(set_aInvMax),aInvStep_(set_aInvStep),eMin_(set_eMin), eMax_(set_eMax), eStep_(set_eStep), basis_(set_basis) {
  Init();

  calcAllPairs(aInvMin_, aInvMax_, aInvStep_, eMin_, eMax_, eStep_);
  
}

// Destructor
energies::~energies() {
}

// Loads in a new basis and updates the class data
void energies::setBasis( basis new_basis) {
  
  Init();

  calcAllPairs(aInvMin_, aInvMax_, aInvStep_, eMin_, eMax_, eStep_);

}

void energies::Init() {

  // Initialize the matrices G0 and T12 to the identity 
  G0_.resize( basis_.basisDim(), basis_.basisDim() ); 
  G0_=MatrixXd::Identity( basis_.basisDim(),basis_.basisDim() );
  T12_.resize( basis_.basisDim(), basis_.basisDim() );
  
}

// Prints the pairs using cout
void energies::printPairs() {

  cout<<"The best eigenvalue at each inverse a and energy E is \n";
  cout<<"(a , e , best_lambda)\n";

  for( unsigned int i=0; i<numPairs_; i++) {
    cout<<eLambdaPairs_<<"\n";
  }

}

// Saves the pairs to a file with the default name "a_e_best.csv"
void energies::writePairs() {

  string filename("Data/a_e_best.csv");

  writePairs(filename);
}

// Creates a csv file with a,e, best lambda triads on each row
void energies::writePairs(string filename) {
  
  ofstream file;
  file.open(filename.c_str());

  // Header
  // file << "a,e,lambda\n";

  
  for(unsigned int i=0; i<numPairs_; i++) {

    file<<eLambdaPairs_(i,0)<<","<<eLambdaPairs_(i,1)<<","<<eLambdaPairs_(i,2)<<"\n";

  }

  file.close();

}

void energies::sortPairsByA() {

  Vector3d temp;
  bool flag=0;

  for( unsigned int i=0; i<numPairs_; i++) {

    for( unsigned int j=0; j<numPairs_-1; j++) {

      if( eLambdaPairs_(j,0)> eLambdaPairs_(j+1,0) ) {

	temp=eLambdaPairs_.row(j);
	
	eLambdaPairs_.row(j)=eLambdaPairs_.row(j+1);

	eLambdaPairs_.row(j+1)=temp;

	flag=1;

      }
      
    }

    if (flag==0) break;

    else flag=0;

  }

}

// Calculates the HO Green's function matrix at energy E
void energies::setG0(double E) {

  for(unsigned int i=0; i<basis_.basisDim(); i++) G0_(i,i)= 1/(E - 2*basis_.getBasisState(i).n() - basis_.getBasisState(i).l() - 2*basis_.getBasisState(i).N()- basis_.getBasisState(i).L() - 3 );
		 
}

// Calculates the two body t-matrix for a regulated two-body contact interaction at energy E and interaction strength a
void energies::setT12(double E, double aInv) {

  HOstate state,primeState;

  double temp;

  for(unsigned int i=0; i<basis_.basisDim(); i++) {
    
    if(basis_.getBasisState(i).l()==0 ) {

      primeState=basis_.getBasisState(i);
      
      for (unsigned int j=0; j<basis_.basisDim(); j++ ) {
	
	state=basis_.getBasisState(j);

	// If N=N',L=L',l=l'=0 use 2-body t-matrix
	if( state.N()==primeState.N() && state.L()==primeState.L() && state.l()==0 ) {
	  
	  temp=( LogGamma(primeState.n()+1.5)+LogGamma(state.n()+1.5)-LogGamma(primeState.n()+1.0)-LogGamma(state.n()+1) )/2.0;
	  temp=exp( temp );

	  temp*=2*ROOT2/PI;
	  
	  temp*=C0( E, aInv,state.N(),state.L() );	  
	  
	}
	
	// Otherwise the entries are zero
	else temp=0;

	T12_(i,j)= temp;
	T12_(j,i)= temp;
	
      } // End j loop
    } // End if (l'==0)
    
    // Inserts zeros when l'!=0
    else for (unsigned int j=0; j<basis_.basisDim(); j++ ) {
	T12_(i,j)=0;
	T12_(j,i)=0;
      } // End else for

  } // End i loop
  
}

// Required by setT12, defined as in Tom's notes
double energies::C0(double E, double aInv, int N, int L) {

  double c0=0.0;
  int imax= (basis_.nmax()-2.0*N-L )/2.0;

  // // Return zero for special case a=0
  // if(a==0) return 0;

  // Calculate according to Tom's notes
  for(int i=0; i<=imax; i++ ) {
    c0+=exp( LogGamma(i+1.5) - LogGamma(i+1) )/( 2.0*i+1.5-(E-2*N-L-1.5) ) ;
  }

  c0*= -2*ROOT2/PI;

  c0-= ROOT2*gammaTerm(E-2*N-L-1.5);

  c0+=aInv;

  return 1.0/c0;

}

// The gamma function arguments can be negative, provide cases 
double energies::gammaTerm(double x) {

  if(.25-x/2 > 0) return exp(LogGamma( .75 -x/2 ) - LogGamma(.25-x/2) );

  else if ( .75-x/2>0 ) return exp(LogGamma( .75 -x/2 ) + LogGamma(.75+x/2) )*sin( PI*(.25-x/2) )/PI;
  
  else return exp( LogGamma(.75+x/2) - LogGamma(.25+x/2) )*sin( PI*(.25-x/2) )/sin( PI*(.75-x/2) );
  
}

// Calculates the eigenvalue of G0*t12 closest to 1 at aInv, e
// Returns 0 if no good eigenvalue found, 1 if successful 
// Saves result to Vector3d passed by pointer
bool energies::calcPair(double aInv,double e, Vector3d * pair) {

  MatrixXd mm(basis_.statesDim(),basis_.statesDim());
  VectorXd vec(basis_.basisDim());
  VectorXd primeVec(basis_.basisDim());

  double best=12345; // Start with a large number

  // Generate the matrix
  for(unsigned int i=0; i<basis_.statesDim(); i++) {

    primeVec=basis_.getState(i);

    for(unsigned int j=0; j<basis_.statesDim(); j++) {

      vec=basis_.getState(j);

      mm(i,j)=2*primeVec.transpose()*G0_*T12_*vec;

    } //end j loop
  } // end i loop

  // Calculate the eigenvalues
  EigenSolver<MatrixXd> eigensolver(mm);

  // Find eigenvalue closest to 1
  for( unsigned int i=0; i<basis_.statesDim(); i++ ) {
    
    if( fabs(eigensolver.eigenvalues()(i).real()-1) < fabs(best-1) ) best=eigensolver.eigenvalues()(i).real();
    
  }// end i loop
  
  // Print an error and return FALSE if no good eigenvalue was found
  if(best==12345) {
    cout<<"Error, no good eigenvalues\n";
    return 0;
  }
    
  // If a good eigenvalue was found, save it into the Vector3d and return TRUE
  else {
    (*pair)(0)=aInv;
    (*pair)(1)=e;  
    (*pair)(2)=best;
    return 1;
  }

}

void energies::calcAllPairs(double aInvMin, double aInvMax, double aInvStep, double eMin, double eMax, double eStep) {

  bool flag;

  numPairs_=0;

  Vector3d tempPair;

  for( double e=eMin; e<=eMax; e+=eStep ) {

    setG0(e);

    for( double aInv=aInvMin; aInv<=aInvMax; aInv+=aInvStep) {

      setT12(e,aInv);

      numPairs_++;

      eLambdaPairs_.conservativeResize(numPairs_,3);
      
      flag=calcPair(aInv,e, &tempPair );
      
      // If a good eigenvalue was found, add to set
      if(flag==1) eLambdaPairs_.row(numPairs_-1)=tempPair;

      // Otherwise decrement numPairs. Then the next loop will not resize. In case of 
      // last loop, the if statement below takes care of removing the unfilled last row
      else numPairs_--;

      //cout<<"Percent complete: "<< 100*( (aInv-aInvMin)/aInvStep+(e-eMin)/eStep*(aInvMax -aInvMin)/aInvStep ) / ( (aInvMax -aInvMin)/aInvStep * (eMax-eMin)/eStep )<<"\n";

    } // end aInv loop

    //cout<<"Percent complete: "<< 100*( e-eMin ) / ( eMax-eMin )<<"\n";

  } // end e loop 

  // If the last calcPairs return false, resize eLambdaPairs
  if (numPairs_!=eLambdaPairs_.rows() ) eLambdaPairs_.conservativeResize(numPairs_,3);

}
