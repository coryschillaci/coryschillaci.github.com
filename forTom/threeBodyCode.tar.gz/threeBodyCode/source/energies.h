#ifndef energies_H
#define energies_H

#define PI 3.14159265358979
#define ROOT2 1.41421356237310

#include <iostream>
#include <fstream>
#include <Eigen/Dense>
#include <string.h>

#include "HOstate.h"
#include "coupling.h"
#include "basis.h"
#include "gamma.h"

class energies {
 public:
  energies( basis set_basis );
  energies( basis set_basis, double set_aInvMin, double set_aInvMax, double set_aInvStep, double set_eMin, double set_eMax, double set_eStep );
  ~energies();

  // Loads in a new basis and updates the class data
  void setBasis( basis new_basis);
  
  void printT12() {cout<<"The two-body t-matrix is \n"<<T12_<<"\n";};
  void printG0() {cout<<"The HO Green's function is \n"<<G0_<<"\n";};

  void printPairs();
  void writePairs();
  void writePairs(string filename);
  void sortPairsByA(); // Sorts pairs by aInv

 private:
  double aInvMin_,aInvMax_,aInvStep_;
  double eMin_,eMax_,eStep_;
    

  unsigned int numPairs_; // The total number of pairs (e,lambda_best) saved

  basis basis_;
  
  MatrixXd G0_;
  MatrixXd T12_;

  Matrix<double, Dynamic, 3> eLambdaPairs_;

  void Init();

  void setG0(double E);
  void setT12(double E, double aInv);

  bool calcPair(double aInv,double e, Vector3d * pair);
  void calcAllPairs(double aInvMin, double aInvMax, double aInvStep, double eMin, double eMax, double eStep);

  double C0(double E, double aInv, int N, int L);
  double gammaTerm(double x);


};

#endif
